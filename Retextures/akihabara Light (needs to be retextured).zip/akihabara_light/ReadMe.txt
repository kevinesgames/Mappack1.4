Original : �|���|(http://ponzugta.blog3.fc2.com/)
Conventions road : 41aeimi(http://oldiessportcars.blog.fc2.com/)
Low TXD : NINJA PANDA(http://gta.iinaa.net/)

Put all files in the gta3.img